THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MiorSoft/"Roberto Mior" BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

This Version:

https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_SimpleNN.zip

Older Versions  Download Links: 

https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_V20.zip
https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_V13.zip (EXPERIMENTAL)
https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_V12.zip
https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_V11.zip

https://dl.dropboxusercontent.com/u/51621154/____LEARN_2Dsticks_NEAT.zip   'Experimental


SORRY: Dropbox will discontinue the use of public Folder so the above downloads will not be available.
Visit: https://miorsoft.github.io/Site/index.html


Make me Happy! Contribute:

https://www.patreon.com/miorsoft
or PayPal to reexre@gmail.com


Last UpDate: 15/11/2016

Improved Creature Editor (Undo/Redo and Move Point)

for Proplems/Suggetsions feel free to email at reexre@gmail.com

