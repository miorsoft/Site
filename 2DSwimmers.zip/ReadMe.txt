2D Swimmers evolution


To run you need to Download and Register vbRichClient-Framework (vbRichClient5.dll) from www.vbrichclient.com
To Start Simulation from Zero delete POP.txt and SW.txt



Support:
https://www.patreon.com/miorsoft
Web:
https://miorsoft.github.io/Site/index.html