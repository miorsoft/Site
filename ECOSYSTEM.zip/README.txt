This is a Simulation of Living Creatures.
It simulates a small evolutionary ecosystem.
Short explanation:
Each Creature is moved according to its Nerual Network Inputs/Outputs.
Neural Networks Inputs are given by the eyes View,
plus: Current Energy, Current Stomach fullness and 'pregnant or not'.
Eyes View is divided in sectors, each one has the Amount of meat/vegetable food and Male/Female Creature.
The Outputs of NN determinate the Speed and the Steer of the creature.
Creature can reproduce.
There are Males (Yellow) and Female (Pink)
When Male and Female touch themself, female can get Pregnant (In this case she is highlighted)
After a given time then, if pregnant Female has more than 50% of the energy,
She makes a new Child having for genes the one of Mother crossovered with the one of Father.
The mother gives a percentage (given by a gene) of its energy to the son.
A little mutation of children genes can occur.
While Moving, Creatures lose energy that they can recover by eating food.
When out of energy they die and becomes meat-food (That with time will be transformed to Vegetable food).
Vegetable food grows.
If the amount of Global vegetable growth is less than a threshold new Vegetable will be added at random position.
The output of NN, beside Speed and the Steer of the creature, determines the Violence (Red eyes) and Attack behavior of the creature.
If the genes difference of touching creatures (of the same sex) is above a certain threshold (given by a gene) and the 'DoAttack' output of NN is ON, the Attacking creature will damage other creature.

Created by Miorsoft - Roberto Mior
_


How to run it on Windows:
Unzip and Run Ecosystem.exe
Please report Errors or Suggestions to the Author: reexre@gmail.com


Tricks:
- For TURBO mode Check the "Turbo Button" and/or minimize the Window.
- Since it is needed some time to see some evolution result , at startup be patient. It is better to Minimize the window and re-Maximize it after some minutes (1-2 Hours of simulation time).
- After a long run Save the Oldest Creatures or the ones you like. (You can reuse them later or in another Run using the "Add Creature" or "Repopulate" Buttons.)
- To Zoom move (Left-Right) mouse with right button pressed.



*********************
DOWNLOAD and UPDATES:
*********************
https://miorsoft.itch.io/ecosystem-evolution
https://github.com/miorsoft/Site/raw/master/ECOSYSTEM.zip

WEBPAGE:
https://miorsoft.github.io/Site/index.html


CHANGELOG:

2020-01-03:
- New walk method with corrected leg shadows.
- Fix Vision Bug (did not rotate when no food in vision field).
- NRG waste by Speed^2.

2020-01-07 (3):
- Added Mass Gene.
- If N of Females < 5 then add a Random Creature
- Added blood effect
- Included BIN folder. Now no need to download/register RC5.

2020-01-20 (4):
- Added Turbo Button (Maximize speed)
- Removed a part of the eyes input that distinguished between vegetable food and meat.
- Added new input to the neural net: Health
- Added new output: WillToHaveSon, so a new child is born only when the sum of these outputs of the 2 touching creatures of different sex is greater than 1.(This output is represented by a heart drawn on the top)
- Improvements in speed and changed NN layers topology.
- Added Tweakable Settings (Just few for now)

2020-01-29 (5):
- Added other Creature's NN parameters settings.
- Bug fix on Creature Info Display
- Process priority from Idle to Below normal.
- Now children can't Attack.

2020-03-20 (6):
- Added Creatures NRG Decay setting.

2020-11-17 (6):
- Faster (Newest vbRichClient version)


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MiorSoft/"Roberto Mior" BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


